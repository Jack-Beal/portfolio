
/**
 * This is the main code that calls apon other classes to make the game work
 *
 * @author Jack Beal
 * @version 17.11.25
 */

import java.util.Scanner;
import java.io.*;

public class main
{
    public static void main(String[] args){
        int choice=0; //define the choice variable
        Scanner input = new Scanner (System.in); //define to receive inputs
        
        //Main menu loop - continues forever until the user selects exit 
        while (choice != 4){
        //Ask the user what they would like to select from the menu 
        System.out.println("Please select from the following");
        System.out.println("1. Start Game");
        System.out.println("2. Load Game");
        System.out.println("3. Help / Instructions");
        System.out.println("4. Exit");
        
        choice = readInt(input, 1, 4);
        
        //option one starts a new game
        if (choice == 1){
            Player player1 = new Player(); //create the player 1 object
            Player player2 = new Player(); //create the player 2 object
            
            //Get and set the name for player 1
            System.out.print("Enter Player 1 name: ");
            player1.setName(input.nextLine());
            
            //Get and set the name for player 2
            System.out.print("Enter Player 2 name: ");
            player2.setName(input.nextLine());
            
            //Initialize the grids for both players 
            player1.createGrid();
            player2.createGrid();
            
            //Creates the hidden grid which has creatures on it
            player1.createHiddenGrid();
            player2.createHiddenGrid();
            
            //Places the creatures on the hidden board
            player1.creatures();
            player2.creatures();
            
            playGame(player1, player2, input);
        } //Load a saved game 
        else if (choice == 2){
            loadGame(input);
        } //Display information
        else if (choice == 3){
            information(input);
        } //Exit the game
        else if (choice == 4){
            System.out.println("Exiting Game");
            break;
        }
        else{ //Handle any other inputs except 1-4
            System.out.println("Invalid Input please enter number 1 to 4");
        }
    }
    }
    
    //Main game loop - continues until someone has 100 points
    public static void playGame(Player currentPlayer, Player opponent, Scanner input) {
            //Sets up the game loop
            boolean gameOver = false;
            int menuCounter = 0;
            while (gameOver==false) {
                //display name of current player
                System.out.println("It is " + currentPlayer.getName() +"'s turn."); 
                //Displays the current players board 
                System.out.println("Here is the board:"); 
                currentPlayer.displayGrid();
                //displays information about the current player
                System.out.println("You are currently on " + currentPlayer.getScore() + " points.");
                System.out.println("You are currently on " + currentPlayer.getPlayerHealth() + " health.");    
                    
                    /**
                    *Was going to ask the player to type menu to show menu however
                    *this stopped input validation from working proper so they have to 
                    *press 1 to skip it. Now it asks every 4 turn
                    */
                   
                
                if (menuCounter >= 4) {
                    //Resets menu counter
                    menuCounter = 0;
                    
                    //Show menu
                    System.out.println("-- Pause Menu --");
                    System.out.println("1. Resume Game");
                    System.out.println("2. Save Game");
                    System.out.println("3. Save and Exit");
                    System.out.println("4. Exit");
                    
                    int menuChoice = readInt(input, 1, 4); //Gets user choice
                
                    if (menuChoice == 1){
                         //resumes the game
                    }
                    else if (menuChoice == 2 ) {
                        saveGame(currentPlayer, opponent, input); //Saves Game
                    }
                    else if (menuChoice == 3 ) {
                        saveGame(currentPlayer, opponent, input); //Saves game
                        gameOver=true; //Ends the game
                        continue; //Exits
                    }
                    else if (menuChoice == 4 ) {
                        System.out.println("Are you sure you want to quit? (1 for Yes, 2 for No):");
                        if (readInt(input,1,2)==1) {gameOver=true;} //If they enter yes then game ends
                        
                    }}

                //Ask for coordinates
                System.out.print("Enter row (0-15): "); //X coordinate
                int row = readInt(input,0, 15); 
                
                System.out.print("Enter column (0-15): "); //Y Coordinate
                int col = readInt(input, 0, 15);
                
                
                //check board and mark
                String[][] grid = currentPlayer.getGrid();  //setting the grid to the current player grid
                String[][] hiddenGrid = currentPlayer.getHiddenGrid(); //setting the hidden grid to current players
                
                if(hiddenGrid[row][col].equals("-")) { //seeing if the guessed spot is blank
                    //if it is blank the player is told its blank and boards updated 
                    System.out.println("Miss"); 
                    grid[row][col] = "M";
                    hiddenGrid[row][col] = "M";} 
                else if(hiddenGrid[row][col].equals("M")|| hiddenGrid[row][col].equals("H")) {
                    System.out.println("You have already guessed here."); 
                    //if the user puts in a already guessed spot they are told and the loop restarts
                    System.out.println("Please guess again"); 
                    continue;
                }
                else if( //These are all hits each is a different type of fish
                hiddenGrid[row][col].equals("V") ||
                hiddenGrid[row][col].equals("A") ||
                hiddenGrid[row][col].equals("C") ||
                hiddenGrid[row][col].equals("S")
                ) {
                    System.out.println("HIT"); //Tells the player they hit and updates the board
                    grid[row][col] = hiddenGrid[row][col]; //reveals creature on visible grid
                    hiddenGrid[row][col] = "H"; //Marks it down as a hit
                    currentPlayer.increaseScore(); //increases score of player by 5
                    continue;
                }
                
                //check if current player has 100 points 
                if (currentPlayer.getScore()>=100){
                    gameOver = true; //game is won
                    System.out.println(currentPlayer.getName() + " has won the game!"); //win message
                    System.out.println("---");
                    System.out.println("Game Stats:");
                    
                    //Display Stats for both players (winner first)
                    for (int playerNum = 1; playerNum <= 2; playerNum++){
                    System.out.println(currentPlayer.getName() + "'s Stats:");
                    System.out.println(currentPlayer.getScore() + " Points");
                    System.out.println(currentPlayer.getPlayerHealth() + " Health");
                    System.out.println(currentPlayer.getScore() + " Score");
                    System.out.println("You guessed " +currentPlayer.getGuesses());
                    
                    //Show the complete grid for hidden 
                    System.out.println("Full Grid");
                    currentPlayer.displayHiddenGrid();
                    
                    //Show the grid of the player guesses 
                    System.out.println("Player guesses grid");
                    currentPlayer.displayGrid();
                    
                    //Swap the players being displayed 
                    Player temp = currentPlayer;
                    currentPlayer = opponent;
                    opponent = temp;
                    }
                }
                
                //increases the guesses of current player
                currentPlayer.increaseGuesses();
                
                //Menu Counter increase
                menuCounter += 1;
                
                //Swaps the players around 
                Player temp = currentPlayer;
                currentPlayer = opponent;
                opponent = temp;
                System.out.println("-----");
            }
        }
    
    /**
     * Saves the current game stats to one file 
     */
    private static void saveGame(Player currentPlayer, Player opponent, Scanner input) {
        try {
        //Gets user to enter the name of the file they want
        System.out.println("Enter save name: ");
        String fileName = input.nextLine() + ".txt";
        
        PrintWriter writer = new PrintWriter(new FileWriter(fileName));
        
        //Save current player to indicate who goes next
        writer.println("CURRENT_PLAYER");
        writer.println(currentPlayer.getName());
        
        //Save player 1 data 
        writer.println("PLAYER1");
        savePlayerData(writer, currentPlayer);
        
        //Save player 2 data
        writer.println("PLAYER2");
        savePlayerData(writer, opponent);
        
        //Close the file writer 
        writer.close();
        System.out.println("Game saved"); //Display success message 
    }
        catch (IOException e) { //Handles any errors received 
            System.out.println("Error when saving: " + e.getMessage());
        }
    }
    
    /**
     * This saves the player data to the file in a way that we can then read back out
     */
    private static void savePlayerData(PrintWriter writer, Player player) {
        //Writes data about the player into the file
        writer.println(player.getName());
        writer.println(player.getScore());
        writer.println(player.getPlayerHealth());
        writer.println(player.getGuesses());
        
        //Saves the visible grid 
        writer.println("GRID");
        String[][] grid = player.getGrid();
        for (int row = 0; row < 16; row++) {
            for (int col = 0; col < 16; col++) {
                writer.print(grid[row][col] + " ");
            }writer.println();}
            
        //Saves the visible grid 
        writer.println("HIDDEN_GRID");
        String[][] hiddenGrid = player.getHiddenGrid();
        for (int row = 0; row < 16; row++) {
            for (int col = 0; col < 16; col++) {
                writer.print(hiddenGrid[row][col] + " ");
            }writer.println();}
    }
    
        
    /**
     * Used to read in the alreaedy saved data 
     */
    private static void loadGame(Scanner input) {
        try {
            System.out.println("Enter save name: "); //get file name
            String fileName = input.nextLine() + ".txt";
            
            Scanner fileReader = new Scanner(new File(fileName));
            
            //Skip "CURRENT_PLAYER" marker then read current player
            fileReader.nextLine();
            String currentPlayerName = fileReader.nextLine();
            
            //Load Player 1 
            fileReader.nextLine(); //Skip "PLAYER1"
            Player player1 = loadPlayerData(fileReader);
            
            //Load Player 2 
            fileReader.nextLine(); //Skip "PLAYER2"
            Player player2 = loadPlayerData(fileReader);
            
            fileReader.close(); //close file
            
            System.out.println("Game Loaded"); //display sucsess message
            
            //make sure correct player starts
            if (player1.getName().equals(currentPlayerName)) { 
                playGame(player1, player2, input);
            } else {
                playGame(player2, player1, input);
            }
        }
        catch (FileNotFoundException e){
            System.out.println("Save file not found!"); //error message
        }
    }
    
    /**
     * Helper method to load single player data
     */
    private static Player loadPlayerData(Scanner fileReader) {
        //Loads basic data about player
        String name = fileReader.nextLine();
        int score = Integer.parseInt(fileReader.nextLine());
        int health = Integer.parseInt(fileReader.nextLine());
        int guesses = Integer.parseInt(fileReader.nextLine());
        
        //Load grids
        fileReader.nextLine(); //Skip "GRID"
        String[][] grid = new String[16][16]; 
        for (int row = 0; row < 16; row++) { //loop for each coordinate
            String[] rowData = fileReader.nextLine().split(" ");
            for (int col = 0; col < 16; col++) {
                grid[row][col] = rowData[col];
            }
        }
        
        fileReader.nextLine(); //Skip "HIDDEN_GRID"
        String[][] hiddenGrid = new String[16][16];
        for (int row = 0; row < 16; row++) { //loop for each coordinate
            String[] rowData = fileReader.nextLine().split(" ");
            for (int col = 0; col < 16; col++) {
                hiddenGrid[row][col] = rowData[col];}
            }
        
        //Create player with all loaded data from the file using the second constructor
        return new Player(name, grid, hiddenGrid, score, health, guesses);
    }
    
    /**
     * Displays information on how to play the game to the player
     * as well as other information about saving, loading
     * and information on the creatures
     */
    public static void information(Scanner input) {
        //create loop
        boolean exit = false; 
        
        while (exit==false){
            //Display menu
            int choice = 0;
            System.out.println("Information Menu");
            System.out.println("1. Game lore");
            System.out.println("2. How to play");
            System.out.println("3. Creature Index / How to read the grid");
            System.out.println("4. Save / Load Instructions");
            System.out.println("5. Exit");
            
            choice = readInt(input, 1, 5); //validate input 
            
            if (choice == 1) { //game lore info
                System.out.println("-------------------");
                System.out.println("GAME LORE");
                System.out.println("-------------------");
                System.out.println("You are exploring the depths of the worlds oceans,");
                System.out.println("looking for different types of creatures.");
                System.out.println("");
                System.out.println("Your mission is to find and locate remaining creatures");
                System.out.println("before they disapear into the depths.");
                System.out.println("");
                System.out.println("But there's one problem...");
                System.out.println("");
                System.out.println("There is a rival explorer who is also trying to find similar creatures elsewhere.");
                System.out.println("Find the creatures first and you win!");
                System.out.println("");
                System.out.println("Good luck explorer.");
                System.out.println("-------------------");
            }
            else if(choice == 2){ //playing info
                System.out.println("-------------------");
                System.out.println("HOW TO PLAY");
                System.out.println("-------------------");
                System.out.println("");
                System.out.println("You have the option to either start a new game or load a saved game");
                System.out.println("If you start a new game you set the name of both players");
                System.out.println("If you select to load a game make sure that you");
                System.out.println("have the correct save name and only type the name not .txt");
                System.out.println("");
                System.out.println("When playing you enter the X coordinate first and then the Y");
                System.out.println("Then the coordinates will be checked and you will be told");
                System.out.println("if its a HIT or a MISS and then also if you have guesses there already");
                System.out.println("you can take your turn again.");
                System.out.println("");
                System.out.println("There is a pause menu that pops up ever 4 turns");
                System.out.println("This allows you to save the game or exit.");
                System.out.println("");
                System.out.println("You win when you reach 100 points.");
                System.out.println("");
                System.out.println("Remember creatures come in lots of differnet shapes");
            }
            else if(choice == 3){ //creature info
                System.out.println("-------------------");
                System.out.println("CREATURE INFO");
                System.out.println("-------------------");
                System.out.println("Here is each creature and their shape");
                System.out.println("");
                System.out.println("-------------------");
                System.out.println("RAY");
                System.out.println("Symbol: V");
                System.out.println("Parts: 5");
                System.out.println("Shape: In a V shape");
                System.out.println("");
                System.out.println("- - - - -");
                System.out.println("- - V - -");
                System.out.println("- V - V -");
                System.out.println("V - - - V");
                System.out.println("- - - - -");
                System.out.println("");
                System.out.println("It can Face any direction.");
                System.out.println("-------------------");
                System.out.println("-------------------");
                System.out.println("ANEMONE");
                System.out.println("Symbol: A");
                System.out.println("Parts: 8");
                System.out.println("Shape: Circular shape");
                System.out.println("");
                System.out.println("- - A - -");
                System.out.println("- A - A -");
                System.out.println("A - - - A");
                System.out.println("- A - A -");
                System.out.println("- - A - -");
                System.out.println("");
                System.out.println("-------------------");
                System.out.println("-------------------");
                System.out.println("FISH");
                System.out.println("Symbol: S");
                System.out.println("Parts: 3");
                System.out.println("Shape: Straight Line");
                System.out.println("");
                System.out.println("- - - - -");
                System.out.println("- - S - -");
                System.out.println("- - S - -");
                System.out.println("- - S - -");
                System.out.println("- - - - -");
                System.out.println("");
                System.out.println("-------------------");
                System.out.println("-------------------");
                System.out.println("CRAB");
                System.out.println("Symbol: C");
                System.out.println("Parts: 1");
                System.out.println("Shape: Dot");
                System.out.println("");
                System.out.println("- - - - -");
                System.out.println("- - - - -");
                System.out.println("- - C - -");
                System.out.println("- - - - -");
                System.out.println("- - - - -");
                System.out.println("");
                System.out.println("-------------------");
                System.out.println("");
                System.out.println("The board displays blank spaces as - ");
                System.out.println("The board displays a MISS as M");
                System.out.println("The board will show guessed creatures with their symbol");
            }
            else if(choice == 4){ //save and load instructions
                System.out.println("-------------------");
                System.out.println("SAVE / LOAD INSTRUCTIONS");
                System.out.println("-------------------");
                System.out.println("");
                System.out.println("Saving your game:");
                System.out.println("Select Save game from the menu.");
                System.out.println("Enter the name for the save file do not put .txt");
                System.out.println("");
                System.out.println("Loading a saved game:");
                System.out.println("Select Load Game on the main menu.");
                System.out.println("Enter the name of your save file.");
                System.out.println("Play the game.");
                System.out.println("");
                System.out.println("Save file tips:");
                System.out.println("Dont put .txt on anything");
                System.out.println("Save files are stored in the game directory");
                System.out.println("You can save the game multiple times");
                System.out.println("Try use names you can remember");
                System.out.println("");
                System.out.println("Make sure you save before leaving or YOU WILL LOSE YOUR GAME");
                System.out.println("");
            }
            else if(choice == 5){ //exit
                exit=true;
                continue;
            }
        }
    }
    
    
    /**
     * Read and validate the input from the user to make sure it falls within 
     * the min and max stated.
     * 
     * This is used for the 1-4 in menu 
     * Also used for gettings coordinate.
     */
    public static int readInt(Scanner input, int min, int max) {
    while (true) {
        if (input.hasNextInt()) {
            int value = input.nextInt(); //Sets value to entered int
            input.nextLine(); //Clears new line
            
            if (value >= min && value <= max) { //checks if input is within the range 
                return value;
            } else {
                System.out.println("Input not valid must be between :" + min + "-" + max);
                //Tells user the range they must enter within
            }
        } else {
            input.nextLine(); //Gets rid of invalid input
            System.out.println("Please enter a number: ");
        }
    }
    }

}

