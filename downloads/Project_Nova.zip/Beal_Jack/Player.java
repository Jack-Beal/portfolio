import java.util.Random;
/**
 *This creates a player object which allows for easier interaction with the game class
 *
 * @author (Jack Beal
 * @version 17.11.25
 */
public class Player
{
    private String name;
    private String[][] grid = new String [16][16];
    private String[][] hiddenGrid = new String [16][16];
    private int score;
    private int playerHealth;
    private int guesses;
    
    //defualt constructor, creates an empty Player object 
    public Player(){ 
        name = "";
        grid = new String[16][16];
        hiddenGrid = new String[16][16];
        score = 0;
        playerHealth = 100;
        guesses = 0;
    }
    
    // second constructor, this will be used to load saves
    public Player(String pName, String[][] pGrid, String[][] pHiddenGrid, int pScore, int pPlayerHealth, int pGuesses){
        name = pName;
        grid = pGrid;
        hiddenGrid = pHiddenGrid;
        score = pScore;
        playerHealth = pPlayerHealth;
        guesses = pGuesses;
    }
    
    // Set and get methods
    //These either return a variable for the get methods or set a variable from information passed in
    public void setName(String newName){
        name = newName;
    }
    
    public String getName(){
        return name;
    }
    
    public void setGrid(String newGrid[][]){
        grid = newGrid;
    }
    
    public String[][] getGrid(){
        return grid;
    }
    
    public void setHiddenGrid(String newHiddenGrid[][]){
        hiddenGrid = newHiddenGrid;
    }
    
    public String[][] getHiddenGrid(){
        return hiddenGrid;
    }
    
    public void setScore(int newScore){
        score = newScore;
    }
    
    public void increaseScore(){
        score += 5;
    }
    
    public int getScore(){
        return score;
    }
    
    public void setPlayerHealth(int newPlayerHealth){
        playerHealth = newPlayerHealth;
    }
    
    public int getPlayerHealth(){
        return playerHealth;
    }
    
    public void setGuesses(int newGuesses){
        guesses = newGuesses;
    }
    
    public int getGuesses(){
        return guesses;
    }
    
    public void increaseGuesses(){
        guesses += 1;
    }
    
    public void createGrid() {
    for (int row = 0; row < 16; row++) {
        for (int col = 0; col < 16; col++) {
            grid[row][col] = "-";
        }
    } }
    
    public void displayGrid() {
        System.out.print("Displaying Grid");
        System.out.println();
        for (int row = 0; row < 16; row++) {

            for (int col = 0; col < 16; col++) {
                System.out.print(grid[row][col] + " ");
            }System.out.println();
    } }
    
    public void createHiddenGrid() {
    for (int row = 0; row < 16; row++) {
        for (int col = 0; col < 16; col++) {
            hiddenGrid[row][col] = "-";
        }
    } }
    
    public void displayHiddenGrid() {
        System.out.print("Displaying Final Grid");
        System.out.println();
        for (int row = 0; row < 16; row++) {
            for (int col = 0; col < 16; col++) {
                System.out.print(hiddenGrid[row][col] + " ");
            }System.out.println();
    } }
    
    public void creatures() {
        //Place select amount of creatures
        placeCreature("A");
        placeCreature("V");
        for (int i=0;i<=1;i++){
            placeCreature("S");
        }
        for (int i=0;i<=2;i++){
            placeCreature("C");
        }
    }
    
    public void placeCreature(String creatureShape) {
        Random random = new Random();
        boolean placed = false;
        
        //randomly select orientation of creatures 
        int x = random.nextInt(4); 
        String direction = ""; 
        
        //orientation is only relevent to V and S creatures as other do not rotate
        if (x == 0) {
            direction = "North";
        }
        else if (x==1) {
            direction = "East";
        }
        else if (x==2) {
            direction = "South";
        }
        else {
            direction = "West";
        }
        
        //loop to keep trying positions until creatures are all placed 
        while (placed == false) {
            //generate random coordiante 
            int row = random.nextInt(16);
            int col = random.nextInt(16);
            
            //initiate area 2d array for creature coordiantes 
            int[][] area = null;
            
            //defines creature shape depending on the type
            if (creatureShape.equals("C")) {
                area = new int[][] {{0,0}};
            }
            else if (creatureShape.equals("S")) {
                
                //determains if the fish is vertical or horizontal 
                if (direction.equals("North") || direction.equals("South")){
                    area = new int[][] {{0,0}, {1,0}, {2,0}} //verticle 
                    ;}
                else {
                    area = new int[][] {{0,0}, {0,1}, {0,2}}; //horizontal
                }
            }
            if (creatureShape.equals("V")) {
                
                //V shape patteren has 5 cells
                
                //changes direction to point in 4 different ways
                if (direction.equals("North")) {
                    area = new int[][] {{-1,-1}, {-1,1},{-2,-2},{-2,2}};
                }
                if (direction.equals("South")) {
                    area = new int[][] {{1,-1}, {1,1},{2,-2},{2,2}};
                }
                if (direction.equals("East")) {
                    area = new int[][] {{-1,-1}, {1,-1},{-2,-2},{2,-2}};
                }
                if (direction.equals("West")) {
                    area = new int[][] {{-1,1}, {1,1},{-2,2},{2,2}};
                }
            }
            
            if (creatureShape.equals("A")) {
                //8 cells in a diamond shape
                area = new int[][] {{-2,0}, {-1,1},{-1,-1},{0,-2},{0,2},
                {1,-1},{1,1},{2,0}};
            }
                
            //try to place if the position is valid 
            if (area != null && canPlace(row,col,area)==true) {
                //for the V shape creature it also has to place the center cell
                if (creatureShape.equals("V")) {
                hiddenGrid[row][col] = creatureShape;}
                
                //place the shape using the coordinates and the area as well as symbol
                placeShape(row,col,area, creatureShape);
                
                placed = true; //makes sure its placed 
            }
                
                
                }
            }
        
    
    private void placeShape(int startRow, int startCol, int[][] area, String symbol) {
        
        for (int i = 0 ;i < area.length; i++) { //loop for length of area array
            int[] coord = area[i];
            int row = startRow + coord[0];
            int col = startCol + coord[1];
            hiddenGrid[row][col] = symbol; //places symbol at the coordinate
    }
    }
    
    private boolean canPlace(int startRow, int startCol, int[][] area) {
        
        for (int i = 0 ;i < area.length; i++) { //loop for length of array
            int[] coord = area[i];
            
            int row = startRow + coord[0];
            int col = startCol + coord[1];
            
            if (row < 0 || row>= 16 || col < 0 || col >=16) { //checks if out of bounds
                return false;
            }
            
            if (!hiddenGrid[row][col].equals("-")) { //checks that coordinate is free
                return false;
            }
        }
        
        return true;
    }
        }

