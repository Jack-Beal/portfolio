# =====================
# Pico B – Aimee (Receiver with Web Interface)
# =====================
import machine
import network
import socket
import time
import ujson
from umqtt.simple import MQTTClient
import neopixel
import patterns_enhanced as patterns

# =====================
# CONFIGURATION
# =====================
SSID = "StudentResidences"
WIFI_PASSWORD = ""

CLIENT_ID = b"aimee_pico"
BROKER = b"dee5eeebc156454fa75687231385bdd3.s1.eu.hivemq.cloud"
USERNAME = b"jackbeal"
PASSWORD = b"Jack1407"

PUB_TOPIC = b"/valentine/aimee"
SUB_TOPIC = b"/valentine/jack"
MUTUAL_TOPIC = b"/valentine/mutual"

# Hardware
NUM_LEDS = 8
LED_PIN = 0
BUTTON_PIN = 2

# =====================
# HARDWARE SETUP
# =====================
strip = neopixel.NeoPixel(machine.Pin(LED_PIN), NUM_LEDS)
button = machine.Pin(BUTTON_PIN, machine.Pin.IN, machine.Pin.PULL_UP)

# =====================
# GLOBAL STATE
# =====================
wlan = None
mqtt = None
web_socket = None

current_pattern = "off"
pattern_running = False
last_button_state = 1
button_press_time = 0

# =====================
# WIFI CONNECTION
# =====================
def wifi_connect():
    global wlan
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    print("Connecting to WiFi...")
    
    if not wlan.isconnected():
        wlan.connect(SSID, WIFI_PASSWORD)
        max_retries = 20
        retry = 0
        while not wlan.isconnected() and retry < max_retries:
            time.sleep(0.5)
            retry += 1
            print(".", end="")
    
    if wlan.isconnected():
        ip = wlan.ifconfig()[0]
        print(f"\nWiFi connected! IP: {ip}")
        return ip
    else:
        print("\nWiFi connection failed!")
        return None

# =====================
# MQTT FUNCTIONS
# =====================
def mqtt_callback(topic, msg):
    global current_pattern, pattern_running
    
    try:
        data = ujson.loads(msg)
        msg_type = data.get("type")
        
        if topic == SUB_TOPIC:
            if msg_type == "pattern":
                pattern_name = data.get("pattern", "heartbeat")
                current_pattern = pattern_name
                pattern_running = True
                print(f"💕 Received pattern from Jack: {pattern_name}")
                
            elif msg_type == "message":
                message = data.get("text", "")
                print(f"💌 Message from Jack: {message}")
                current_pattern = "sparkle"
                pattern_running = True
                
        elif topic == MUTUAL_TOPIC:
            from_who = data.get("from")
            if from_who == "jack":
                their_time = data.get("timestamp")
                if button_press_time > 0:
                    time_diff = abs(their_time - button_press_time)
                    if time_diff < 2.0:
                        current_pattern = "mutual"
                        pattern_running = True
                        print("💕💕 Mutual moment!")
                        
    except Exception as e:
        print(f"MQTT callback error: {e}")

def mqtt_connect():
    global mqtt
    try:
        mqtt = MQTTClient(
            CLIENT_ID,
            BROKER,
            port=8883,
            user=USERNAME,
            password=PASSWORD,
            keepalive=60,
            ssl=True,
            ssl_params={"server_hostname": BROKER},
        )
        mqtt.set_callback(mqtt_callback)
        mqtt.connect()
        mqtt.subscribe(SUB_TOPIC)
        mqtt.subscribe(MUTUAL_TOPIC)
        print("MQTT connected!")
        return True
    except Exception as e:
        print(f"MQTT connection error: {e}")
        return False

def mqtt_send_pattern(pattern_name):
    try:
        mqtt.publish(PUB_TOPIC, ujson.dumps({
            "type": "pattern",
            "pattern": pattern_name
        }))
        print(f"Sent pattern to Jack: {pattern_name}")
        return True
    except Exception as e:
        print(f"MQTT send error: {e}")
        return False

def mqtt_send_message(message):
    try:
        mqtt.publish(PUB_TOPIC, ujson.dumps({
            "type": "message",
            "text": message
        }))
        print(f"Sent message to Jack: {message}")
        return True
    except Exception as e:
        print(f"MQTT send error: {e}")
        return False

# =====================
# WEB SERVER
# =====================
def generate_webpage():
    html = """<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aimee's Valentine Controller</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background: #f0e6ff;
        }
        h1 {
            color: #9333ea;
            text-align: center;
        }
        .section {
            background: white;
            padding: 15px;
            margin: 15px 0;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .section h2 {
            color: #9333ea;
            margin-top: 0;
        }
        button {
            background: #9333ea;
            color: white;
            border: none;
            padding: 10px 15px;
            margin: 5px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }
        button:hover {
            background: #7c22d6;
        }
        .pattern-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }
        input[type="text"] {
            width: calc(100% - 20px);
            padding: 8px;
            margin: 5px 0;
            border: 2px solid #9333ea;
            border-radius: 5px;
        }
        .stop-btn {
            background: #dc3545;
            width: 100%;
            font-size: 16px;
            padding: 12px;
        }
        .status {
            text-align: center;
            color: #666;
            font-style: italic;
        }
    </style>
</head>
<body>
    <h1>💜 Aimee's LED Control 💜</h1>
    
    <div class="section">
        <h2>🎨 Local Patterns</h2>
        <div class="pattern-grid">
            <button onclick="location.href='/pattern/heartbeat'">❤️ Heartbeat</button>
            <button onclick="location.href='/pattern/pulse'">💗 Pulse</button>
            <button onclick="location.href='/pattern/sparkle'">✨ Sparkle</button>
            <button onclick="location.href='/pattern/rainbow'">🌈 Rainbow</button>
            <button onclick="location.href='/pattern/love_wave'">🌊 Love Wave</button>
            <button onclick="location.href='/pattern/garden_breeze'">🌸 Garden</button>
            <button onclick="location.href='/pattern/rose_garden'">🌹 Roses</button>
            <button onclick="location.href='/pattern/romance_album'">🎵 Romance</button>
        </div>
    </div>
    
    <div class="section">
        <h2>💌 Send to Jack</h2>
        <div class="pattern-grid">
            <button onclick="location.href='/send/heartbeat'">❤️ Heartbeat</button>
            <button onclick="location.href='/send/sparkle'">✨ Sparkle</button>
            <button onclick="location.href='/send/love_wave'">🌊 Love Wave</button>
            <button onclick="location.href='/send/garden_breeze'">🌸 Garden</button>
            <button onclick="location.href='/send/rose_garden'">🌹 Roses</button>
            <button onclick="location.href='/send/romance_album'">🎵 Romance</button>
        </div>
        <form action="/send_message" method="get">
            <input type="text" name="msg" placeholder="Type a message for Jack...">
            <button type="submit" style="width: 100%;">Send Message 💕</button>
        </form>
    </div>
    
    <div class="section">
        <button class="stop-btn" onclick="location.href='/stop'">⏹️ STOP</button>
    </div>
    
    <div class="status">
        <p>Current: <strong>{pattern}</strong></p>
        <p><a href="/">Refresh</a></p>
    </div>
</body>
</html>"""
    return html.replace("{pattern}", current_pattern)

def start_web_server(ip):
    global web_socket
    try:
        addr = (ip, 80)
        web_socket = socket.socket()
        web_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        web_socket.bind(addr)
        web_socket.listen(1)
        web_socket.setblocking(False)
        print(f"Web server started on http://{ip}")
        return True
    except Exception as e:
        print(f"Web server error: {e}")
        return False

def handle_web_request():
    global current_pattern, pattern_running, web_socket
    try:
        client, addr = web_socket.accept()
        client.settimeout(2.0)
        request = client.recv(1024).decode('utf-8')
        
        if 'GET /' in request:
            lines = request.split('\n')
            path = lines[0].split()[1]
            
            if path.startswith('/pattern/'):
                pattern_name = path.replace('/pattern/', '').split('?')[0]
                current_pattern = pattern_name
                pattern_running = True
                
            elif path.startswith('/send/'):
                pattern_name = path.replace('/send/', '').split('?')[0]
                mqtt_send_pattern(pattern_name)
                
            elif path.startswith('/send_message'):
                if '?msg=' in path:
                    message = path.split('?msg=')[1].split('&')[0]
                    message = message.replace('+', ' ')
                    mqtt_send_message(message)
                    
            elif path == '/stop':
                current_pattern = "off"
                pattern_running = False
                patterns.clear(strip)
        
        response = "HTTP/1.1 200 OK\r\n"
        response += "Content-Type: text/html\r\n"
        response += "Connection: close\r\n\r\n"
        response += generate_webpage()
        
        client.send(response.encode('utf-8'))
        client.close()
        
    except OSError:
        pass
    except Exception as e:
        print(f"Web request error: {e}")

# =====================
# PATTERN EXECUTION
# =====================
def run_pattern(pattern_name, duration=5):
    if pattern_name == "heartbeat":
        patterns.heartbeat(strip, patterns.DEEP_PINK, duration)
    elif pattern_name == "pulse":
        patterns.pulse(strip, patterns.RED, duration)
    elif pattern_name == "sparkle":
        patterns.sparkle(strip, patterns.WHITE, duration)
    elif pattern_name == "rainbow":
        patterns.rainbow(strip, duration)
    elif pattern_name == "fire":
        patterns.fire(strip, duration)
    elif pattern_name == "scanner":
        patterns.scanner(strip, patterns.RED, duration)
    elif pattern_name == "love_wave":
        patterns.love_wave(strip, duration)
    elif pattern_name == "garden_breeze":
        patterns.garden_breeze(strip, duration)
    elif pattern_name == "spring_meadow":
        patterns.spring_meadow(strip, duration)
    elif pattern_name == "rose_garden":
        patterns.rose_garden(strip, duration)
    elif pattern_name == "romance_album":
        patterns.romance_album(strip, duration)
    elif pattern_name == "romance_pulse":
        patterns.romance_pulse(strip, duration)
    elif pattern_name == "mutual":
        for i in range(NUM_LEDS):
            strip[i] = (255, 0, 100)
        strip.write()
        time.sleep(5)
        patterns.clear(strip)
    else:
        patterns.clear(strip)

# =====================
# BUTTON HANDLING
# =====================
def check_button():
    global last_button_state, button_press_time, current_pattern, pattern_running
    
    current_button = button.value()
    current_time = time.time()
    
    if current_button == 0 and last_button_state == 1:
        button_press_time = current_time
        current_pattern = "heartbeat"
        pattern_running = True
        
        try:
            mqtt.publish(PUB_TOPIC, ujson.dumps({"type": "press"}))
            mqtt.publish(MUTUAL_TOPIC, ujson.dumps({
                "from": "aimee",
                "timestamp": current_time
            }))
        except:
            pass
    
    elif current_button == 1 and last_button_state == 0:
        hold_duration = current_time - button_press_time
        try:
            if hold_duration > 0.5:
                mqtt.publish(PUB_TOPIC, ujson.dumps({
                    "type": "hold",
                    "duration": min(int(hold_duration), 10)
                }))
        except:
            pass
    
    last_button_state = current_button

# =====================
# MAIN PROGRAM
# =====================
def main():
    global pattern_running, current_pattern
    
    print("💜 Aimee's Controller Starting... 💜")
    
    ip = wifi_connect()
    if not ip:
        print("Failed to connect to WiFi!")
        return
    
    mqtt_connect()
    start_web_server(ip)
    
    # Startup animation
    for i in range(3):
        patterns.set_all(strip, patterns.HOT_PINK)
        time.sleep(0.2)
        patterns.clear(strip)
        time.sleep(0.2)
    
    print("✅ System ready!")
    print(f"🌐 Web interface: http://{ip}")
    print("💜 Waiting for love signals...")
    
    last_mqtt_check = time.time()
    
    while True:
        check_button()
        handle_web_request()
        
        if time.time() - last_mqtt_check > 0.1:
            try:
                mqtt.check_msg()
                last_mqtt_check = time.time()
            except OSError:
                print("MQTT reconnecting...")
                time.sleep(1)
                mqtt_connect()
            except:
                pass
        
        if pattern_running and current_pattern != "off":
            run_pattern(current_pattern, duration=5)
            pattern_running = False
            current_pattern = "off"
        
        time.sleep(0.01)

if __name__ == "__main__":
    main()
