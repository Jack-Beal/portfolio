# 💕 Valentine's Day LED Controller System

A romantic LED controller system for Raspberry Pi Pico W that combines MQTT messaging with a web interface. Perfect for couples to send light patterns and messages to each other!

## 🌟 Features

### MQTT Communication
- Send LED patterns between devices
- Text messaging capability
- Mutual press detection (when both press buttons within 2 seconds)
- Real-time message delivery

### Web Interface
- Control LED patterns from your phone/computer
- Send patterns to your partner
- Send text messages
- Local pattern testing
- Works on the same WiFi network

### LED Patterns

#### Original Patterns
- **Heartbeat** - Double pulse like a heartbeat
- **Pulse** - Smooth breathing effect
- **Sparkle** - Random twinkling
- **Rainbow** - Full rainbow cycle
- **Fire** - Flickering flames
- **Scanner** - KITT/Cylon eye effect

#### Romantic Green/Pink Patterns
- **Love Wave** - Pink and green waves flowing together
- **Garden Breeze** - Gentle garden colors with breathing effect
- **Spring Meadow** - Alternating pink and green (spring flowers in grass)
- **Enchanted Forest** - Deep green with magical pink sparkles
- **Rose Garden** - Soft pulsing between pink and sage green
- **Watermelon** - Pink center with green edges

#### Fontaines DC "Romance" Album Theme
- **Romance Album** - Moody dark aesthetic with brooding red pulses and shadows
- **Romance Pulse** - Slow brooding pulse between darkness and blood red
- Colors inspired by the album's dark, emotional intensity

## 📦 Hardware Requirements

### Each Device Needs:
- Raspberry Pi Pico W
- WS2812B LED strip (8 LEDs or more)
- Push button
- Breadboard and wires
- USB power supply

### Wiring:
```
LED Strip:
- Data pin → GPIO 0 (Pin 1)
- VCC → 5V (VBUS)
- GND → GND

Button:
- One side → GPIO 2 (Pin 4)
- Other side → GND
- Internal pull-up resistor used
```

## 🚀 Installation

### 1. Flash MicroPython
Flash MicroPython firmware to both Pico W boards:
- Download from: https://micropython.org/download/rp2-pico-w/
- Hold BOOTSEL button while plugging in USB
- Copy .uf2 file to RPI-RP2 drive

### 2. Upload Files

#### On Jack's Pico:
Upload these files:
- `patterns_enhanced.py` (the enhanced patterns library)
- `valentine_controller.py` (main controller for Jack)

#### On Aimee's Pico:
Upload these files:
- `patterns_enhanced.py` (same patterns library)
- `valentine_controller_aimee.py` (main controller for Aimee)

### 3. Configure WiFi
Edit the WiFi settings in both controller files:
```python
SSID = "YourWiFiNetwork"
WIFI_PASSWORD = "YourPassword"
```

### 4. Hardware Configuration
Adjust these if your hardware differs:
```python
NUM_LEDS = 8          # Number of LEDs in your strip
LED_PIN = 0           # GPIO pin for LED data
BUTTON_PIN = 2        # GPIO pin for button
```

## 🎮 Usage

### Starting the System
1. Connect both Picos to power
2. Wait for WiFi connection (LED will flash pink 3 times when ready)
3. Note the IP addresses printed in the serial console
4. Open web browser on phone: `http://[IP_ADDRESS]`

### Web Interface Features

#### Local Patterns Section
Control the LED strip on YOUR device:
- Click any pattern button to run it locally
- Great for testing patterns
- Immediate visual feedback

#### Send to Partner Section
Send patterns to your partner's device:
- Click pattern buttons to trigger on their device
- Type a message and click "Send Message"
- They'll see the pattern/message instantly

#### Stop Button
- Stops any currently running pattern
- Turns off all LEDs

### Button Controls
- **Quick Press**: Triggers heartbeat pattern on both devices
- **Hold (>0.5s)**: Sends hold duration, triggers glow effect
- **Press Together**: If both press within 2 seconds, special mutual pattern!

## 🎨 Pattern Details

### Romantic Patterns

**Love Wave** 🌊
- Pink and green waves flow across the strip
- Creates a flowing, romantic motion
- Duration: 5 seconds

**Garden Breeze** 🌸
- Randomly alternates between mint green and light pink
- Gentle breathing effect
- Like flowers swaying in a garden

**Spring Meadow** 🌿
- Alternating pink and green blocks
- Chasing effect
- Represents spring flowers in grass

**Rose Garden** 🌹
- Smooth transition between rose pink and sage green
- Soft, romantic pulsing
- Very gentle and calming

### Fontaines DC Patterns

**Romance Album** 🎵
- Dark moody aesthetic with moving shadows
- Brooding red highlights over dark background
- Creates wave patterns with crimson and blood red tones
- Matches the album's emotional intensity

**Dark Pulse** 🖤
- Slow pulse between darkness and blood red
- Holds at peak and in darkness
- Dramatic and atmospheric

## 🔧 Troubleshooting

### WiFi Won't Connect
- Check SSID and password spelling
- Make sure you're using 2.4GHz WiFi (Pico W doesn't support 5GHz)
- Try moving closer to router

### MQTT Not Working
- Check HiveMQ Cloud credentials
- Verify internet connection
- Make sure both devices are online

### Web Server Not Accessible
- Make sure device is connected to WiFi
- Check IP address in serial console
- Try pinging the IP address
- Make sure phone is on same WiFi network

### LEDs Not Working
- Check wiring (data pin, power, ground)
- Verify NUM_LEDS matches your strip
- Make sure LED strip is WS2812B compatible
- Check power supply (LED strips need good power)

### Patterns Not Running
- Check serial console for errors
- Make sure patterns_enhanced.py is uploaded
- Try stopping and starting again

## 📡 MQTT Message Format

### Pattern Command
```json
{
    "type": "pattern",
    "pattern": "heartbeat"
}
```

### Text Message
```json
{
    "type": "message",
    "text": "I love you!"
}
```

### Button Press
```json
{
    "type": "press"
}
```

### Hold Event
```json
{
    "type": "hold",
    "duration": 5
}
```

### Mutual Press
```json
{
    "from": "jack",
    "timestamp": 1234567890.123
}
```

## 🎯 Customization

### Adding New Colors
Edit `patterns_enhanced.py`:
```python
MY_COLOR = (R, G, B)  # RGB values 0-255
```

### Creating New Patterns
Add to `patterns_enhanced.py`:
```python
def my_pattern(strip, duration=5):
    """Your pattern description"""
    end_time = time.time() + duration
    while time.time() < end_time:
        # Your pattern code here
        strip.write()
        time.sleep_ms(50)
    clear(strip)
```

Then add to web interface in controller file:
```python
# In generate_webpage():
<button onclick="location.href='/pattern/my_pattern'">🎨 My Pattern</button>

# In run_pattern():
elif pattern_name == "my_pattern":
    patterns.my_pattern(strip, duration)
```

### Adjusting Pattern Duration
In the controller files, change the duration parameter:
```python
def run_pattern(pattern_name, duration=5):  # Change to 10 for longer patterns
```

## 💡 Tips

1. **Test Locally First**: Use the local patterns section to test before sending
2. **Power Matters**: LED strips can draw a lot of power, use a good USB supply
3. **Mutual Press**: Coordinate with your partner for the special mutual effect
4. **Message Length**: Keep messages short for best display
5. **Network**: Both devices must be on same WiFi for web interface to work

## 🎵 About "Romance" Patterns

The Fontaines DC themed patterns are inspired by their 2024 album "Romance":
- Dark, moody color palette (blacks, deep reds, crimsons)
- Brooding, emotional intensity
- Atmospheric and dramatic effects
- Perfect for when you want something more intense than traditional romantic colors

## 📝 License

Free to use and modify for personal projects!

## ❤️ Created With Love

Made for Jack & Aimee's Valentine's Day 2026 💕

---

**Happy Valentine's Day! May your LEDs always glow bright! 💕✨**
