# =====================
# Enhanced LED Pattern Library
# Valentine's Edition with Romantic Patterns
# =====================
import time
import math

# =====================
# COLOR DEFINITIONS
# =====================
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
CYAN = (0, 255, 255)
MAGENTA = (255, 0, 255)
ORANGE = (255, 165, 0)
PURPLE = (128, 0, 128)
PINK = (255, 192, 203)
DEEP_PINK = (255, 20, 147)
HOT_PINK = (255, 69, 180)
LIGHT_PINK = (255, 182, 193)
ROSE_PINK = (255, 102, 178)
MINT_GREEN = (152, 255, 152)
SAGE_GREEN = (128, 158, 128)
FOREST_GREEN = (34, 139, 34)
LIME_GREEN = (50, 205, 50)

# Fontaines DC "Romance" album colors (dark moody tones with red/black)
ROMANCE_DARK = (20, 20, 25)
ROMANCE_RED = (180, 30, 30)
ROMANCE_CRIMSON = (139, 0, 0)
ROMANCE_BLOOD = (138, 7, 7)
ROMANCE_SHADOW = (40, 40, 45)

RAINBOW_COLORS = [
    (255, 0, 0),    # Red
    (255, 127, 0),  # Orange
    (255, 255, 0),  # Yellow
    (0, 255, 0),    # Green
    (0, 0, 255),    # Blue
    (75, 0, 130),   # Indigo
    (148, 0, 211),  # Violet
]


# =====================
# HELPER FUNCTIONS
# =====================
def set_all(strip, color):
    """Set all LEDs to one color"""
    for i in range(len(strip)):
        strip[i] = color
    strip.write()


def clear(strip):
    """Turn off all LEDs"""
    set_all(strip, BLACK)


def wheel(pos):
    """Generate rainbow colors across 0-255 positions"""
    if pos < 85:
        return (pos * 3, 255 - pos * 3, 0)
    elif pos < 170:
        pos -= 85
        return (255 - pos * 3, 0, pos * 3)
    else:
        pos -= 170
        return (0, pos * 3, 255 - pos * 3)


# =====================
# ORIGINAL PATTERNS
# =====================

def rainbow(strip, duration=5, speed=50):
    """Rainbow cycle across all LEDs"""
    num_leds = len(strip)
    end_time = time.time() + duration
    
    while time.time() < end_time:
        for j in range(255):
            if time.time() >= end_time:
                break
            for i in range(num_leds):
                pixel_index = (i * 256 // num_leds) + j
                strip[i] = wheel(pixel_index & 255)
            strip.write()
            time.sleep_ms(speed)


def pulse(strip, color=RED, duration=3, speed=20):
    """Smooth pulsing effect (breathe in/out)"""
    end_time = time.time() + duration
    
    while time.time() < end_time:
        # Fade in
        for brightness in range(0, 256, 5):
            if time.time() >= end_time:
                break
            r = int(color[0] * brightness / 255)
            g = int(color[1] * brightness / 255)
            b = int(color[2] * brightness / 255)
            set_all(strip, (r, g, b))
            time.sleep_ms(speed)
        
        # Fade out
        for brightness in range(255, -1, -5):
            if time.time() >= end_time:
                break
            r = int(color[0] * brightness / 255)
            g = int(color[1] * brightness / 255)
            b = int(color[2] * brightness / 255)
            set_all(strip, (r, g, b))
            time.sleep_ms(speed)


def heartbeat(strip, color=DEEP_PINK, duration=3):
    """Heartbeat pattern - double beat with pause"""
    end_time = time.time() + duration
    
    while time.time() < end_time:
        # First beat
        for brightness in range(0, 256, 25):
            set_all(strip, tuple(int(c * brightness / 255) for c in color))
            time.sleep_ms(20)
        for brightness in range(255, 0, -25):
            set_all(strip, tuple(int(c * brightness / 255) for c in color))
            time.sleep_ms(20)
        
        time.sleep_ms(100)
        
        # Second beat (smaller)
        for brightness in range(0, 180, 20):
            set_all(strip, tuple(int(c * brightness / 255) for c in color))
            time.sleep_ms(20)
        for brightness in range(180, 0, -20):
            set_all(strip, tuple(int(c * brightness / 255) for c in color))
            time.sleep_ms(20)
        
        time.sleep_ms(500)
    
    clear(strip)


def sparkle(strip, color=WHITE, duration=3, density=0.3):
    """Random sparkling effect"""
    import random
    num_leds = len(strip)
    end_time = time.time() + duration
    
    while time.time() < end_time:
        for i in range(num_leds):
            if random.random() < density:
                strip[i] = color
            else:
                strip[i] = BLACK
        strip.write()
        time.sleep_ms(100)
    
    clear(strip)


def fire(strip, duration=5):
    """Flickering fire effect"""
    import random
    num_leds = len(strip)
    end_time = time.time() + duration
    
    while time.time() < end_time:
        for i in range(num_leds):
            flicker = random.randint(100, 255)
            r = flicker
            g = random.randint(0, flicker // 2)
            b = 0
            strip[i] = (r, g, b)
        strip.write()
        time.sleep_ms(50)
    
    clear(strip)


def scanner(strip, color=RED, duration=3, speed=50):
    """KITT/Cylon scanner effect"""
    num_leds = len(strip)
    end_time = time.time() + duration
    
    while time.time() < end_time:
        # Scan right
        for i in range(num_leds):
            clear(strip)
            strip[i] = color
            if i > 0:
                strip[i - 1] = tuple(c // 4 for c in color)
            if i > 1:
                strip[i - 2] = tuple(c // 8 for c in color)
            strip.write()
            time.sleep_ms(speed)
            if time.time() >= end_time:
                break
        
        # Scan left
        for i in range(num_leds - 1, -1, -1):
            clear(strip)
            strip[i] = color
            if i < num_leds - 1:
                strip[i + 1] = tuple(c // 4 for c in color)
            if i < num_leds - 2:
                strip[i + 2] = tuple(c // 8 for c in color)
            strip.write()
            time.sleep_ms(speed)
            if time.time() >= end_time:
                break
    
    clear(strip)


# =====================
# NEW ROMANTIC PATTERNS
# =====================

def love_wave(strip, duration=5, speed=80):
    """
    Pink and green waves flowing together romantically
    """
    num_leds = len(strip)
    end_time = time.time() + duration
    offset = 0
    
    while time.time() < end_time:
        for i in range(num_leds):
            # Create wave effect with sine
            wave_pos = (i + offset) % (num_leds * 2)
            
            if wave_pos < num_leds:
                # Pink wave
                intensity = int(255 * abs(math.sin(wave_pos * math.pi / num_leds)))
                strip[i] = (intensity, int(intensity * 0.7), int(intensity * 0.8))
            else:
                # Green wave
                intensity = int(255 * abs(math.sin((wave_pos - num_leds) * math.pi / num_leds)))
                strip[i] = (int(intensity * 0.3), intensity, int(intensity * 0.5))
        
        strip.write()
        time.sleep_ms(speed)
        offset = (offset + 1) % (num_leds * 2)
    
    clear(strip)


def garden_breeze(strip, duration=5, speed=60):
    """
    Gentle green and pink colors like flowers in a garden
    """
    import random
    num_leds = len(strip)
    end_time = time.time() + duration
    
    # Initialize with random green/pink
    led_colors = []
    for i in range(num_leds):
        if random.random() > 0.5:
            led_colors.append(MINT_GREEN)
        else:
            led_colors.append(LIGHT_PINK)
    
    while time.time() < end_time:
        # Slowly change some LEDs
        if random.random() > 0.7:
            idx = random.randint(0, num_leds - 1)
            if led_colors[idx] == MINT_GREEN:
                led_colors[idx] = LIGHT_PINK
            else:
                led_colors[idx] = MINT_GREEN
        
        # Apply colors with breathing effect
        brightness = int(200 + 55 * math.sin(time.time() * 2))
        for i in range(num_leds):
            color = led_colors[i]
            strip[i] = tuple(int(c * brightness / 255) for c in color)
        
        strip.write()
        time.sleep_ms(speed)
    
    clear(strip)


def spring_meadow(strip, duration=5, speed=100):
    """
    Alternating pink and green like spring flowers in grass
    """
    num_leds = len(strip)
    end_time = time.time() + duration
    offset = 0
    
    while time.time() < end_time:
        for i in range(num_leds):
            pos = (i + offset) % 4
            if pos < 2:
                strip[i] = ROSE_PINK
            else:
                strip[i] = LIME_GREEN
        
        strip.write()
        time.sleep_ms(speed)
        offset = (offset + 1) % 4
    
    clear(strip)


def enchanted_forest(strip, duration=5, speed=70):
    """
    Deep greens with magical pink sparkles
    """
    import random
    num_leds = len(strip)
    end_time = time.time() + duration
    
    # Base layer: green
    set_all(strip, FOREST_GREEN)
    
    while time.time() < end_time:
        # Random pink sparkles
        for i in range(num_leds):
            if random.random() < 0.1:
                strip[i] = HOT_PINK
            elif strip[i] == HOT_PINK:
                strip[i] = FOREST_GREEN
        
        strip.write()
        time.sleep_ms(speed)
    
    clear(strip)


def rose_garden(strip, duration=5):
    """
    Soft pulsing between pink and sage green
    """
    num_leds = len(strip)
    end_time = time.time() + duration
    
    while time.time() < end_time:
        # Pink to green
        for step in range(50):
            if time.time() >= end_time:
                break
            ratio = step / 50
            r = int(ROSE_PINK[0] + (SAGE_GREEN[0] - ROSE_PINK[0]) * ratio)
            g = int(ROSE_PINK[1] + (SAGE_GREEN[1] - ROSE_PINK[1]) * ratio)
            b = int(ROSE_PINK[2] + (SAGE_GREEN[2] - ROSE_PINK[2]) * ratio)
            set_all(strip, (r, g, b))
            time.sleep_ms(40)
        
        # Green to pink
        for step in range(50):
            if time.time() >= end_time:
                break
            ratio = step / 50
            r = int(SAGE_GREEN[0] + (ROSE_PINK[0] - SAGE_GREEN[0]) * ratio)
            g = int(SAGE_GREEN[1] + (ROSE_PINK[1] - SAGE_GREEN[1]) * ratio)
            b = int(SAGE_GREEN[2] + (ROSE_PINK[2] - SAGE_GREEN[2]) * ratio)
            set_all(strip, (r, g, b))
            time.sleep_ms(40)
    
    clear(strip)


def watermelon(strip, duration=5, speed=100):
    """
    Pink inside with green edges like a watermelon slice
    """
    num_leds = len(strip)
    end_time = time.time() + duration
    
    # Static pattern
    for i in range(num_leds):
        if i < 2 or i >= num_leds - 2:
            strip[i] = FOREST_GREEN  # Green rind
        else:
            strip[i] = HOT_PINK  # Pink flesh
    strip.write()
    
    time.sleep(duration)
    clear(strip)


# =====================
# FONTAINES DC "ROMANCE" PATTERN
# =====================

def romance_album(strip, duration=8, speed=80):
    """
    Moody dark aesthetic inspired by Fontaines DC's Romance album
    Dark background with brooding red pulses and shadows
    """
    num_leds = len(strip)
    end_time = time.time() + duration
    phase = 0
    
    while time.time() < end_time:
        for i in range(num_leds):
            # Create moody gradient with moving shadows
            wave = math.sin((i / num_leds * 2 * math.pi) + (phase * 0.1))
            
            # Base dark tone
            if wave > 0.5:
                # Crimson highlights
                intensity = int((wave - 0.5) * 2 * 255)
                r = int(ROMANCE_CRIMSON[0] * intensity / 255)
                g = int(ROMANCE_CRIMSON[1] * intensity / 255)
                b = int(ROMANCE_CRIMSON[2] * intensity / 255)
                strip[i] = (r, g, b)
            elif wave > 0:
                # Dark red shadows
                intensity = int(wave * 2 * 255)
                r = int(ROMANCE_BLOOD[0] * intensity / 255)
                g = int(ROMANCE_BLOOD[1] * intensity / 255)
                b = int(ROMANCE_BLOOD[2] * intensity / 255)
                strip[i] = (r, g, b)
            else:
                # Deep shadows
                strip[i] = ROMANCE_SHADOW
        
        strip.write()
        time.sleep_ms(speed)
        phase += 1
    
    clear(strip)


def romance_pulse(strip, duration=5):
    """
    Slow brooding pulse between darkness and blood red
    Like the album's emotional intensity
    """
    end_time = time.time() + duration
    
    while time.time() < end_time:
        # Fade in to blood red
        for brightness in range(0, 256, 3):
            if time.time() >= end_time:
                break
            r = int(ROMANCE_BLOOD[0] * brightness / 255)
            g = int(ROMANCE_BLOOD[1] * brightness / 255)
            b = int(ROMANCE_BLOOD[2] * brightness / 255)
            set_all(strip, (r, g, b))
            time.sleep_ms(30)
        
        # Hold at peak
        time.sleep_ms(200)
        
        # Fade out to shadow
        for brightness in range(255, -1, -3):
            if time.time() >= end_time:
                break
            r = int(ROMANCE_BLOOD[0] * brightness / 255)
            g = int(ROMANCE_BLOOD[1] * brightness / 255)
            b = int(ROMANCE_BLOOD[2] * brightness / 255)
            set_all(strip, (r, g, b))
            time.sleep_ms(30)
        
        # Hold in darkness
        set_all(strip, ROMANCE_SHADOW)
        time.sleep_ms(500)
    
    clear(strip)


# =====================
# DEMO FUNCTION
# =====================
def demo_all(strip):
    """Run through all patterns to showcase them"""
    print("Rainbow...")
    rainbow(strip, duration=3)
    time.sleep(0.5)
    
    print("Pulse...")
    pulse(strip, RED, duration=3)
    time.sleep(0.5)
    
    print("Heartbeat...")
    heartbeat(strip, DEEP_PINK, duration=3)
    time.sleep(0.5)
    
    print("Sparkle...")
    sparkle(strip, WHITE, duration=3)
    time.sleep(0.5)
    
    print("Scanner...")
    scanner(strip, RED, duration=3)
    time.sleep(0.5)
    
    print("Love Wave...")
    love_wave(strip, duration=3)
    time.sleep(0.5)
    
    print("Garden Breeze...")
    garden_breeze(strip, duration=3)
    time.sleep(0.5)
    
    print("Rose Garden...")
    rose_garden(strip, duration=3)
    time.sleep(0.5)
    
    print("Romance Album...")
    romance_album(strip, duration=3)
    time.sleep(0.5)
    
    print("Demo complete!")
    clear(strip)
