# 🎨 Quick Pattern Reference Guide

## 💖 Classic Romantic Patterns

### Heartbeat ❤️
- **Colors**: Deep pink
- **Effect**: Double pulse (lub-dub) with pause
- **Vibe**: Classic romantic, emotional
- **Best for**: "Thinking of you" moments

### Pulse 💗
- **Colors**: Red (customizable)
- **Effect**: Smooth breathing in and out
- **Vibe**: Gentle, calming
- **Best for**: Ambient romantic lighting

### Sparkle ✨
- **Colors**: White (customizable)
- **Effect**: Random twinkling lights
- **Vibe**: Magical, dreamy
- **Best for**: Messages, special moments

---

## 🌸 Pink & Green Romantic Collection

### Love Wave 🌊
- **Colors**: Pink → Green waves
- **Effect**: Flowing waves across strip
- **Vibe**: Dynamic, flowing love
- **Best for**: When you want movement and energy
- **Symbolism**: Two hearts in motion together

### Garden Breeze 🌸
- **Colors**: Mint green + Light pink
- **Effect**: Random alternation with breathing
- **Vibe**: Gentle, natural, fresh
- **Best for**: Peaceful romantic moments
- **Symbolism**: Flowers swaying in a garden

### Spring Meadow 🌿
- **Colors**: Rose pink + Lime green
- **Effect**: Alternating blocks that chase
- **Vibe**: Playful, cheerful, vibrant
- **Best for**: Happy, energetic messages
- **Symbolism**: Spring flowers in grass

### Enchanted Forest 🌲✨
- **Colors**: Forest green base + Hot pink sparkles
- **Effect**: Deep green with random pink magic
- **Vibe**: Mysterious, magical
- **Best for**: Surprising your partner
- **Symbolism**: Finding magic in unexpected places

### Rose Garden 🌹
- **Colors**: Rose pink ↔ Sage green
- **Effect**: Smooth transitions, pulsing
- **Vibe**: Soft, romantic, elegant
- **Best for**: Calm, intimate moments
- **Symbolism**: Classic romance (roses) meets nature

### Watermelon 🍉
- **Colors**: Pink center, green edges
- **Effect**: Static pattern
- **Vibe**: Playful, summery, sweet
- **Best for**: Cute, lighthearted messages
- **Symbolism**: Sweet inside, protected outside

---

## 🎵 Fontaines DC "Romance" Album Theme

### Romance Album 🎵
- **Colors**: Dark shadows + Crimson + Blood red
- **Effect**: Moody waves with moving shadows
- **Vibe**: Intense, brooding, atmospheric
- **Best for**: Deep emotional connection
- **When to use**: When romance feels powerful and dark
- **Album reference**: Captures the album's emotional depth

### Dark Pulse 🖤
- **Colors**: Shadow dark ↔ Blood red
- **Effect**: Slow dramatic pulse with holds
- **Vibe**: Dramatic, intense, passionate
- **Best for**: Strong emotions, passion
- **When to use**: When you want to convey intensity
- **Album reference**: The heartbeat of dark romance

---

## 🌈 Classic Effects

### Rainbow 🌈
- **Colors**: Full spectrum
- **Effect**: Cycling rainbow wheel
- **Vibe**: Joyful, colorful, celebratory
- **Best for**: Happy moments, celebrations

### Fire 🔥
- **Colors**: Red, orange, yellow
- **Effect**: Flickering flames
- **Vibe**: Passionate, intense, warm
- **Best for**: Passionate messages, warmth

### Scanner 👁️
- **Colors**: Red (customizable)
- **Effect**: KITT/Cylon eye scan
- **Vibe**: Retro, cool, searching
- **Best for**: Fun, playful moments

---

## 💡 Pattern Selection Guide

### By Mood

**Feeling Romantic**: Heartbeat, Pulse, Rose Garden
**Feeling Playful**: Spring Meadow, Sparkle, Watermelon
**Feeling Peaceful**: Garden Breeze, Rose Garden, Pulse
**Feeling Passionate**: Fire, Dark Pulse, Romance Album
**Feeling Magical**: Enchanted Forest, Sparkle, Love Wave
**Feeling Intense**: Romance Album, Dark Pulse, Fire

### By Time of Day

**Morning**: Spring Meadow, Garden Breeze, Rainbow
**Afternoon**: Love Wave, Sparkle, Rose Garden
**Evening**: Pulse, Heartbeat, Rose Garden
**Night**: Romance Album, Dark Pulse, Enchanted Forest

### By Message Type

**"I Love You"**: Heartbeat, Love Wave, Romance Pulse
**"Thinking of You"**: Sparkle, Pulse, Rose Garden
**"Miss You"**: Heartbeat, Dark Pulse, Rose Garden
**"You Make Me Happy"**: Spring Meadow, Rainbow, Garden Breeze
**"You're Beautiful"**: Enchanted Forest, Rose Garden, Sparkle
**Intense Passion**: Fire, Dark Pulse, Romance Album

### By Relationship Energy

**New Love**: Spring Meadow, Sparkle, Love Wave
**Established Love**: Heartbeat, Rose Garden, Pulse
**Deep Connection**: Romance Album, Dark Pulse, Enchanted Forest
**Playful Love**: Watermelon, Spring Meadow, Rainbow

---

## 🎭 Creating Sequences

Combine patterns for storytelling:

### "Complete Romance" Sequence
1. Garden Breeze (3s) - Fresh start
2. Love Wave (5s) - Growing feelings
3. Heartbeat (5s) - Deep connection
4. Rose Garden (5s) - Established love

### "Dark Romance" Sequence
1. Enchanted Forest (3s) - Mystery
2. Romance Album (8s) - Depth
3. Dark Pulse (5s) - Intensity
4. Sparkle (3s) - Magic moment

### "Spring Love" Sequence
1. Spring Meadow (3s) - New beginnings
2. Garden Breeze (5s) - Growing together
3. Rose Garden (5s) - Blooming love
4. Love Wave (5s) - Forever flowing

---

## 🎨 Color Psychology

### Pink Tones
- **Light Pink**: Gentle love, tenderness
- **Rose Pink**: Romance, beauty
- **Deep Pink**: Passion, gratitude
- **Hot Pink**: Energy, excitement

### Green Tones
- **Mint Green**: Freshness, renewal
- **Sage Green**: Calm, harmony
- **Lime Green**: Energy, growth
- **Forest Green**: Stability, depth

### Red Tones (Romance Album)
- **Crimson**: Intense passion
- **Blood Red**: Raw emotion
- **Dark Shadows**: Mystery, depth

---

## 💭 Pattern Meanings

**Heartbeat**: "My heart beats for you"
**Love Wave**: "Our love flows together"
**Garden Breeze**: "You make life beautiful"
**Spring Meadow**: "You bring spring to my life"
**Rose Garden**: "Classic and timeless love"
**Enchanted Forest**: "You're magical"
**Romance Album**: "Deep, complex emotions"
**Dark Pulse**: "Intense connection"
**Sparkle**: "You light up my world"

---

## 🌟 Pro Tips

1. **Duration Matters**: Longer patterns (8-10s) for important messages
2. **Timing**: Send patterns when you know they're looking
3. **Sequences**: Chain patterns together for storytelling
4. **Mutual Press**: Coordinate for the special mutual effect
5. **Contrast**: Follow intense patterns with calm ones
6. **Surprise**: Mix up your pattern choices to keep things fresh

---

**Remember**: The best pattern is the one that expresses what you feel! 💕
