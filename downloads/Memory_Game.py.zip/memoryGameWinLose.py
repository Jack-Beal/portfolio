#type: ignore
from machine import Pin
from time import sleep
import random
from sys import exit
import network
import ssl
import ubinascii
import ujson
from umqtt.simple import MQTTClient

#MODIFY THIS STUFF HERE
SSID = "TheNet"
WIFI_PASSWORD = "12344567"

CLIENT_ID = b'MemoryBoard'
HIVE_URL = b'aca7dc597bcf4f98888065f1d6cd4fcb.s1.eu.hivemq.cloud'
USERNAME = b'all__'
PASSWORD = b'masterfulPassword1'

#The topic we're publishing to (in this case, a button press)
PUB_TOPIC = b'/condition'

# Wifi Connection Setup as usual
def wifi_connect():
    print('Connecting to wifi...')
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.connect(SSID, WIFI_PASSWORD)
    while wlan.isconnected() == False:
        print('Waiting for connection...')
        time.sleep(0.5)
    print('Connection details: %s' % str(wlan.ifconfig()))

class Components:
    def __init__(self, led, button, colour):
        self.led = led
        self.button = button
        self.colour = colour

# Set pin 15 as input with pull-up resistor
buttonRed = Pin(6, Pin.IN, Pin.PULL_UP)
buttonGreen = Pin(9, Pin.IN, Pin.PULL_UP)
buttonYellow = Pin(8, Pin.IN, Pin.PULL_UP)
buttonBlue = Pin(7, Pin.IN, Pin.PULL_UP)
ledRed = Pin(2,Pin.OUT)
ledGreen = Pin(5, Pin.OUT)
ledYellow = Pin(4, Pin.OUT)
ledBlue = Pin(3, Pin.OUT)


red = Components(ledRed, buttonRed, "red")
blue = Components(ledBlue, buttonBlue, "blue")
green = Components(ledGreen, buttonGreen, "green")
yellow = Components(ledYellow, buttonYellow, "yellow")

components_array = [red, blue, green, yellow]

def randomLEDAddArray(LEDList):
    numberLED = random.choice(components_array)
    LEDList.append(numberLED)
    return LEDList

def main(LEDlist,speed):
    storedList = randomLEDAddArray(LEDlist)
    for x in storedList:
        sleep(speed)
        x.led.on()
        sleep(speed)
        x.led.off()
    #for x in storedList:
        #print(x.colour)
    for x in storedList:
        buttonPressed = False
        while buttonPressed == False:
            if x.button.value() == 0:
                sleep(0.05)
                if x.button.value() == 0:
                    while x.button.value() == 0:
                        sleep(0.01)
                        x.led.on()
                        if x.button.value() == 1:
                            break
                        #print("Holding")
                    buttonPressed = True
                    roundStatus = 'win'
                    #print("Press")
                    x.led.off()
            for y in components_array:
                if y != x:
                    if y.button.value() == 0:
                        counter = 0 
                        for counter in range(len(components_array)):
                            components_array[counter].led.on()
                        print(len(LEDlist))
                        roundStatus = 'lose'
                        message = b'{"state":"%s"}' % roundStatus
                        print('Publishing topic %s message %s' % (PUB_TOPIC, message))
                        mqtt.publish(topic=PUB_TOPIC, msg=message)
                        for x in storedList:
                            print(x.colour, end=" ")
                        exit()
    return roundStatus

# Connect to WiFi
wifi_connect()

# Set HiveMQTT connection details
mqtt = MQTTClient(
    client_id=CLIENT_ID,
    server=HIVE_URL,
    port=8883,
    user=USERNAME,
    password=PASSWORD,
    keepalive=5000,
    ssl=True,
    ssl_params={'server_hostname': HIVE_URL})

# Establish connection to HiveMQTT
mqtt.connect()

if __name__ == '__main__':
    LEDlist = []
    for x in components_array:
        x.led.off()
    print("Please select speed: Blue is slow, Yellow is normal, Green is fast and red is really fast")
    buttonPressed=False
    while buttonPressed==False:
        if components_array[0].button.value()==0:
            buttonPressed=True
            speed=0.25
            components_array[0].led.on()
        if components_array[1].button.value()==0:
            buttonPressed=True
            speed=2
            components_array[1].led.on()
        if components_array[2].button.value()==0:
            buttonPressed=True
            speed=0.5
            components_array[2].led.on()
        if components_array[3].button.value()==0:
            buttonPressed=True
            speed=1
            components_array[3].led.on()
    sleep(0.5)
    for x in components_array:
        x.led.on()
    sleep(1)
    for x in components_array:
        x.led.off()
    while True:
        roundStatus = main(LEDlist,speed)
        message = b'{"state":"%s"}' % roundStatus
        print('Publishing topic %s message %s' % (PUB_TOPIC, message))
        mqtt.publish(topic=PUB_TOPIC, msg=message)